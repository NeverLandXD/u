const menunsfw = (prefix, sender) => {
        return `
❍ 𝙼𝙴𝙽𝚄 𝙽𝚂𝙵𝚆
 
  ║➩ ❍ #nsfwbobs
  ║➩ ❍ #randomhentai
  ║➩ ❍ #nsfwtrap
  ║➩ ❍ #nsfwass
  ║➩ ❍ #nsfwbelly
  ║➩ ❍ #nsfwsidebobs
  ║➩ ❍ #nsfwahegao
  ║➩ ❍ #nsfwthighs
  ║➩ ❍ #nsfwarmpits
  ║➩ ❍ #nsfwfeets
`
}

exports.menunsfw = menunsfw
